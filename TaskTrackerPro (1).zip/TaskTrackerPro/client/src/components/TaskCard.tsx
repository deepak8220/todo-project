import { useState } from "react";
import { format, isToday, isPast } from "date-fns";
import { Calendar, User, Users, MoreVertical, Share, Trash2, Circle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { cn } from "@/lib/utils";
import type { TaskWithOwnerAndCollaborators } from "@shared/schema";

interface TaskCardProps {
  task: TaskWithOwnerAndCollaborators;
  onUpdate: (id: number, updates: Partial<TaskWithOwnerAndCollaborators>) => void;
  onDelete: (id: number) => void;
  currentUserId: string;
}

export default function TaskCard({ task, onUpdate, onDelete, currentUserId }: TaskCardProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isShareDialogOpen, setIsShareDialogOpen] = useState(false);
  const [collaboratorEmail, setCollaboratorEmail] = useState("");

  const isOwner = task.ownerId === currentUserId;
  const isOverdue = task.dueDate && isPast(new Date(task.dueDate)) && task.status !== "completed";
  const isDueToday = task.dueDate && isToday(new Date(task.dueDate));

  // Share task mutation
  const shareTaskMutation = useMutation({
    mutationFn: async (email: string) => {
      await apiRequest("POST", `/api/tasks/${task.id}/collaborators`, { email });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      setCollaboratorEmail("");
      setIsShareDialogOpen(false);
      toast({
        title: "Success",
        description: "Task shared successfully",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to share task",
        variant: "destructive",
      });
    },
  });

  const handleStatusChange = (checked: boolean) => {
    const newStatus = checked ? "completed" : "todo";
    onUpdate(task.id, { status: newStatus });
  };

  const handleShareTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (collaboratorEmail.trim()) {
      shareTaskMutation.mutate(collaboratorEmail.trim());
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "bg-destructive text-destructive-foreground";
      case "medium":
        return "bg-warning text-warning-foreground";
      case "low":
        return "bg-success text-success-foreground";
      default:
        return "bg-secondary text-secondary-foreground";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-success text-success-foreground";
      case "in_progress":
        return "bg-warning text-warning-foreground";
      case "todo":
        return "bg-secondary text-secondary-foreground";
      default:
        return "bg-secondary text-secondary-foreground";
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "completed":
        return "Completed";
      case "in_progress":
        return "In Progress";
      case "todo":
        return "Todo";
      default:
        return status;
    }
  };

  const getUserInitials = (firstName?: string, lastName?: string, email?: string) => {
    if (firstName && lastName) {
      return `${firstName[0]}${lastName[0]}`.toUpperCase();
    }
    if (firstName) {
      return firstName[0].toUpperCase();
    }
    if (email) {
      return email[0].toUpperCase();
    }
    return "U";
  };

  return (
    <>
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-start space-x-4 flex-1">
            <div className="mt-1">
              <Checkbox
                checked={task.status === "completed"}
                onCheckedChange={handleStatusChange}
                className="w-5 h-5"
              />
            </div>
            <div className="flex-1">
              <h3
                className={cn(
                  "text-lg font-semibold text-gray-900 mb-2",
                  task.status === "completed" && "line-through text-gray-500"
                )}
              >
                {task.title}
              </h3>
              {task.description && (
                <p className="text-gray-600 text-sm mb-3">{task.description}</p>
              )}

              <div className="flex items-center space-x-4 text-sm text-gray-500">
                {task.dueDate && (
                  <div className="flex items-center space-x-1">
                    <Calendar className="w-4 h-4" />
                    <span
                      className={cn(
                        isOverdue && "text-destructive font-medium",
                        isDueToday && "text-warning font-medium"
                      )}
                    >
                      {format(new Date(task.dueDate), "MMM d, yyyy")}
                      {isOverdue && " (Overdue)"}
                      {isDueToday && !isOverdue && " (Today)"}
                    </span>
                  </div>
                )}
                <div className="flex items-center space-x-1">
                  <User className="w-4 h-4" />
                  <span>
                    {task.owner.firstName && task.owner.lastName
                      ? `${task.owner.firstName} ${task.owner.lastName}`
                      : task.owner.email || "Unknown"}
                  </span>
                </div>
                {task.collaborators.length > 0 && (
                  <div className="flex items-center space-x-1">
                    <Users className="w-4 h-4" />
                    <span>{task.collaborators.length} collaborators</span>
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="flex items-center space-x-3">
            <Badge className={getPriorityColor(task.priority)}>
              {task.priority.charAt(0).toUpperCase() + task.priority.slice(1)} Priority
            </Badge>
            <Badge className={getStatusColor(task.status)}>
              {getStatusLabel(task.status)}
            </Badge>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm">
                  <MoreVertical className="w-4 h-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => setIsShareDialogOpen(true)}>
                  <Share className="w-4 h-4 mr-2" />
                  Share
                </DropdownMenuItem>
                {isOwner && (
                  <DropdownMenuItem 
                    onClick={() => onDelete(task.id)}
                    className="text-destructive"
                  >
                    <Trash2 className="w-4 h-4 mr-2" />
                    Delete
                  </DropdownMenuItem>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>

        {/* Collaborators */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="flex -space-x-2">
              {/* Owner avatar */}
              <Avatar className="w-8 h-8 border-2 border-white">
                <AvatarImage src={task.owner.profileImageUrl || undefined} />
                <AvatarFallback className="text-xs">
                  {getUserInitials(task.owner.firstName, task.owner.lastName, task.owner.email)}
                </AvatarFallback>
              </Avatar>
              
              {/* Collaborator avatars */}
              {task.collaborators.slice(0, 2).map((collab) => (
                <Avatar key={collab.id} className="w-8 h-8 border-2 border-white">
                  <AvatarImage src={collab.user.profileImageUrl || undefined} />
                  <AvatarFallback className="text-xs">
                    {getUserInitials(collab.user.firstName, collab.user.lastName, collab.user.email)}
                  </AvatarFallback>
                </Avatar>
              ))}
              
              {task.collaborators.length > 2 && (
                <div className="w-8 h-8 rounded-full border-2 border-white bg-gray-100 flex items-center justify-center text-xs font-medium text-gray-600">
                  +{task.collaborators.length - 2}
                </div>
              )}
            </div>
            
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsShareDialogOpen(true)}
              className="text-primary hover:text-blue-700"
            >
              <Share className="w-4 h-4 mr-1" />
              Share
            </Button>
          </div>

          {task.updatedAt && (
            <div className="text-xs text-gray-500">
              {task.status === "completed" ? "Completed" : "Updated"}{" "}
              {format(new Date(task.updatedAt), "MMM d, yyyy 'at' h:mm a")}
            </div>
          )}
        </div>
      </div>

      {/* Share Dialog */}
      <Dialog open={isShareDialogOpen} onOpenChange={setIsShareDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Share Task</DialogTitle>
            <DialogDescription>
              Add collaborators to this task by entering their email address.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleShareTask}>
            <div className="space-y-4">
              <div>
                <Label htmlFor="email">Email Address</Label>
                <Input
                  id="email"
                  type="email"
                  value={collaboratorEmail}
                  onChange={(e) => setCollaboratorEmail(e.target.value)}
                  placeholder="Enter email address..."
                  required
                />
              </div>
            </div>
            <DialogFooter className="mt-6">
              <Button
                type="button"
                variant="outline"
                onClick={() => setIsShareDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={shareTaskMutation.isPending}>
                {shareTaskMutation.isPending ? "Sharing..." : "Share Task"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
}
