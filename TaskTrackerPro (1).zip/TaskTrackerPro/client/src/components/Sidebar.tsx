import { cn } from "@/lib/utils";
import { 
  Inbox, 
  Calendar, 
  AlertTriangle, 
  Users,
  Circle
} from "lucide-react";

interface SidebarProps {
  activeFilter: string;
  onFilterChange: (filter: string) => void;
  taskCounts?: {
    total: number;
    today: number;
    overdue: number;
    shared: number;
  };
}

export default function Sidebar({ activeFilter, onFilterChange, taskCounts }: SidebarProps) {
  const filters = [
    {
      id: "all",
      label: "All Tasks",
      icon: Inbox,
      count: taskCounts?.total || 0,
      color: "bg-primary text-white"
    },
    {
      id: "today",
      label: "Today",
      icon: Calendar,
      count: taskCounts?.today || 0,
      color: "bg-warning text-white"
    },
    {
      id: "overdue",
      label: "Overdue",
      icon: AlertTriangle,
      count: taskCounts?.overdue || 0,
      color: "bg-destructive text-white"
    },
    {
      id: "shared",
      label: "Shared",
      icon: Users,
      count: taskCounts?.shared || 0,
      color: "bg-secondary text-white"
    }
  ];

  const priorities = [
    { id: "high", label: "High Priority", color: "bg-destructive" },
    { id: "medium", label: "Medium Priority", color: "bg-warning" },
    { id: "low", label: "Low Priority", color: "bg-success" }
  ];

  return (
    <aside className="w-64 bg-white shadow-lg border-r border-gray-200 hidden lg:block">
      <div className="p-6">
        <div className="flex items-center space-x-3 mb-8">
          <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
            <Inbox className="text-white text-lg" />
          </div>
          <h1 className="text-xl font-bold text-gray-900">TaskFlow</h1>
        </div>

        <nav className="space-y-6">
          <div>
            <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3">
              Views
            </h3>
            <ul className="space-y-1">
              {filters.map((filter) => {
                const Icon = filter.icon;
                return (
                  <li key={filter.id}>
                    <button
                      onClick={() => onFilterChange(filter.id)}
                      className={cn(
                        "flex items-center w-full px-3 py-2 text-sm font-medium rounded-lg transition-colors",
                        activeFilter === filter.id
                          ? "text-primary bg-blue-50"
                          : "text-gray-700 hover:text-primary hover:bg-gray-50"
                      )}
                    >
                      <Icon className="w-5 h-5 mr-3" />
                      {filter.label}
                      <span
                        className={cn(
                          "ml-auto text-xs px-2 py-1 rounded-full",
                          filter.color
                        )}
                      >
                        {filter.count}
                      </span>
                    </button>
                  </li>
                );
              })}
            </ul>
          </div>

          <div>
            <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3">
              Priority
            </h3>
            <ul className="space-y-1">
              {priorities.map((priority) => (
                <li key={priority.id}>
                  <button
                    onClick={() => onFilterChange(priority.id)}
                    className="flex items-center w-full px-3 py-2 text-sm font-medium text-gray-700 hover:text-primary hover:bg-gray-50 rounded-lg transition-colors"
                  >
                    <Circle className={cn("w-3 h-3 mr-3 rounded-full", priority.color)} />
                    {priority.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </nav>
      </div>
    </aside>
  );
}
