import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { CheckCircle, Users, Clock, Zap } from "lucide-react";

export default function Landing() {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="container mx-auto px-4 py-16">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="flex items-center justify-center space-x-3 mb-8">
            <div className="w-12 h-12 bg-primary rounded-lg flex items-center justify-center">
              <CheckCircle className="text-white text-2xl" />
            </div>
            <h1 className="text-4xl font-bold text-gray-900">TaskFlow</h1>
          </div>
          <h2 className="text-2xl font-semibold text-gray-900 mb-4">
            Collaborative Todo Management
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto mb-8">
            Manage your tasks and collaborate with your team in real-time. 
            Stay organized, meet deadlines, and achieve your goals together.
          </p>
          <Button 
            onClick={handleLogin}
            size="lg"
            className="px-8 py-3 text-lg"
          >
            Get Started
          </Button>
        </div>

        {/* Features */}
        <div className="grid md:grid-cols-3 gap-8 mb-16">
          <Card className="text-center">
            <CardContent className="pt-6">
              <Users className="w-12 h-12 text-primary mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">Real-time Collaboration</h3>
              <p className="text-gray-600">
                Share tasks with your team and see updates in real-time. 
                Work together seamlessly.
              </p>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardContent className="pt-6">
              <Clock className="w-12 h-12 text-primary mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">Smart Organization</h3>
              <p className="text-gray-600">
                Filter by priority, due date, and status. Never miss a deadline 
                with smart notifications.
              </p>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardContent className="pt-6">
              <Zap className="w-12 h-12 text-primary mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">Instant Updates</h3>
              <p className="text-gray-600">
                Get notified immediately when tasks are updated, completed, 
                or shared with you.
              </p>
            </CardContent>
          </Card>
        </div>

        {/* CTA */}
        <div className="text-center">
          <Card className="max-w-2xl mx-auto">
            <CardContent className="pt-6">
              <h3 className="text-2xl font-semibold mb-4">Ready to get organized?</h3>
              <p className="text-gray-600 mb-6">
                Join thousands of users who trust TaskFlow to manage their tasks 
                and collaborate effectively.
              </p>
              <Button 
                onClick={handleLogin}
                size="lg"
                className="px-8 py-3"
              >
                Sign In to Continue
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
