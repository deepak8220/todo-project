import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertTaskSchema, insertTaskCollaboratorSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Task routes
  app.get('/api/tasks', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const {
        page = 1,
        limit = 10,
        status,
        priority,
        sortBy = "createdAt",
        sortOrder = "desc",
        search,
        filter = "all"
      } = req.query;

      const result = await storage.getTasks({
        userId,
        page: parseInt(page as string),
        limit: parseInt(limit as string),
        status: status as string,
        priority: priority as string,
        sortBy: sortBy as string,
        sortOrder: sortOrder as "asc" | "desc",
        search: search as string,
        filter: filter as "all" | "today" | "overdue" | "shared",
      });

      res.json(result);
    } catch (error) {
      console.error("Error fetching tasks:", error);
      res.status(500).json({ message: "Failed to fetch tasks" });
    }
  });

  app.get('/api/tasks/counts', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const counts = await storage.getTaskCounts(userId);
      res.json(counts);
    } catch (error) {
      console.error("Error fetching task counts:", error);
      res.status(500).json({ message: "Failed to fetch task counts" });
    }
  });

  app.get('/api/tasks/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const taskId = parseInt(req.params.id);
      const task = await storage.getTask(taskId, userId);
      
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }

      res.json(task);
    } catch (error) {
      console.error("Error fetching task:", error);
      res.status(500).json({ message: "Failed to fetch task" });
    }
  });

  app.post('/api/tasks', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const taskData = insertTaskSchema.parse({
        ...req.body,
        ownerId: userId,
      });

      const task = await storage.createTask(taskData);
      
      // Broadcast task creation to WebSocket clients
      broadcastToTask(task.id, 'task_created', { task });

      res.status(201).json(task);
    } catch (error) {
      console.error("Error creating task:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid task data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create task" });
    }
  });

  app.patch('/api/tasks/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const taskId = parseInt(req.params.id);
      const updateData = insertTaskSchema.partial().parse(req.body);

      const updatedTask = await storage.updateTask(taskId, updateData, userId);
      
      if (!updatedTask) {
        return res.status(404).json({ message: "Task not found or access denied" });
      }

      // Broadcast task update to WebSocket clients
      broadcastToTask(taskId, 'task_updated', { task: updatedTask });

      res.json(updatedTask);
    } catch (error) {
      console.error("Error updating task:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid task data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update task" });
    }
  });

  app.delete('/api/tasks/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const taskId = parseInt(req.params.id);

      const deleted = await storage.deleteTask(taskId, userId);
      
      if (!deleted) {
        return res.status(404).json({ message: "Task not found or access denied" });
      }

      // Broadcast task deletion to WebSocket clients
      broadcastToTask(taskId, 'task_deleted', { taskId });

      res.status(204).send();
    } catch (error) {
      console.error("Error deleting task:", error);
      res.status(500).json({ message: "Failed to delete task" });
    }
  });

  // Task collaboration routes
  app.post('/api/tasks/:id/collaborators', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const taskId = parseInt(req.params.id);
      const { email } = req.body;

      if (!email) {
        return res.status(400).json({ message: "Email is required" });
      }

      const added = await storage.addTaskCollaborator(taskId, userId, email);
      
      if (!added) {
        return res.status(400).json({ message: "Failed to add collaborator" });
      }

      // Broadcast collaborator addition
      broadcastToTask(taskId, 'collaborator_added', { taskId, email });

      res.status(201).json({ message: "Collaborator added successfully" });
    } catch (error) {
      console.error("Error adding collaborator:", error);
      res.status(500).json({ message: "Failed to add collaborator" });
    }
  });

  app.delete('/api/tasks/:id/collaborators/:collaboratorId', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const taskId = parseInt(req.params.id);
      const collaboratorId = req.params.collaboratorId;

      const removed = await storage.removeTaskCollaborator(taskId, userId, collaboratorId);
      
      if (!removed) {
        return res.status(404).json({ message: "Collaborator not found or access denied" });
      }

      // Broadcast collaborator removal
      broadcastToTask(taskId, 'collaborator_removed', { taskId, collaboratorId });

      res.status(204).send();
    } catch (error) {
      console.error("Error removing collaborator:", error);
      res.status(500).json({ message: "Failed to remove collaborator" });
    }
  });

  const httpServer = createServer(app);

  // WebSocket setup for real-time updates
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  const taskRooms = new Map<number, Set<WebSocket>>();

  wss.on('connection', (ws: WebSocket, req) => {
    console.log('WebSocket client connected');

    ws.on('message', (data) => {
      try {
        const message = JSON.parse(data.toString());
        
        if (message.type === 'join_task') {
          const taskId = parseInt(message.taskId);
          if (!taskRooms.has(taskId)) {
            taskRooms.set(taskId, new Set());
          }
          taskRooms.get(taskId)!.add(ws);
        } else if (message.type === 'leave_task') {
          const taskId = parseInt(message.taskId);
          const room = taskRooms.get(taskId);
          if (room) {
            room.delete(ws);
            if (room.size === 0) {
              taskRooms.delete(taskId);
            }
          }
        }
      } catch (error) {
        console.error('Error parsing WebSocket message:', error);
      }
    });

    ws.on('close', () => {
      // Remove from all rooms
      for (const [taskId, room] of taskRooms.entries()) {
        room.delete(ws);
        if (room.size === 0) {
          taskRooms.delete(taskId);
        }
      }
      console.log('WebSocket client disconnected');
    });
  });

  // Helper function to broadcast to task room
  function broadcastToTask(taskId: number, type: string, data: any) {
    const room = taskRooms.get(taskId);
    if (room) {
      const message = JSON.stringify({ type, data });
      room.forEach(ws => {
        if (ws.readyState === WebSocket.OPEN) {
          ws.send(message);
        }
      });
    }
  }

  return httpServer;
}
