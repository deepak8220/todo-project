import {
  users,
  tasks,
  taskCollaborators,
  type User,
  type UpsertUser,
  type Task,
  type InsertTask,
  type TaskWithOwnerAndCollaborators,
  type InsertTaskCollaborator,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, or, desc, asc, ilike, count, gte, lt, ne } from "drizzle-orm";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  getUserByEmail(email: string): Promise<User | undefined>;

  // Task operations
  getTasks(params: {
    userId: string;
    page?: number;
    limit?: number;
    status?: string;
    priority?: string;
    sortBy?: string;
    sortOrder?: "asc" | "desc";
    search?: string;
    filter?: "all" | "today" | "overdue" | "shared";
  }): Promise<{ tasks: TaskWithOwnerAndCollaborators[]; total: number }>;
  getTask(id: number, userId: string): Promise<TaskWithOwnerAndCollaborators | undefined>;
  createTask(task: InsertTask): Promise<Task>;
  updateTask(id: number, task: Partial<InsertTask>, userId: string): Promise<Task | undefined>;
  deleteTask(id: number, userId: string): Promise<boolean>;

  // Task collaboration
  addTaskCollaborator(taskId: number, userId: string, email: string): Promise<boolean>;
  removeTaskCollaborator(taskId: number, userId: string, collaboratorId: string): Promise<boolean>;
  getTaskCollaborators(taskId: number): Promise<(typeof taskCollaborators.$inferSelect & { user: User })[]>;

  // Task counts for sidebar
  getTaskCounts(userId: string): Promise<{
    total: number;
    today: number;
    overdue: number;
    shared: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async getTasks(params: {
    userId: string;
    page?: number;
    limit?: number;
    status?: string;
    priority?: string;
    sortBy?: string;
    sortOrder?: "asc" | "desc";
    search?: string;
    filter?: "all" | "today" | "overdue" | "shared";
  }): Promise<{ tasks: TaskWithOwnerAndCollaborators[]; total: number }> {
    const { 
      userId, 
      page = 1, 
      limit = 10, 
      status, 
      priority, 
      sortBy = "createdAt", 
      sortOrder = "desc", 
      search, 
      filter = "all" 
    } = params;
    const offset = (page - 1) * limit;

    let query = db
      .select({
        task: tasks,
        owner: users,
      })
      .from(tasks)
      .innerJoin(users, eq(tasks.ownerId, users.id))
      .leftJoin(taskCollaborators, eq(tasks.id, taskCollaborators.taskId))
      .where(
        or(
          eq(tasks.ownerId, userId),
          eq(taskCollaborators.userId, userId)
        )
      );

    // Apply filters
    if (status) {
      query = query.where(and(query._.where, eq(tasks.status, status)));
    }

    if (priority) {
      query = query.where(and(query._.where, eq(tasks.priority, priority)));
    }

    if (search) {
      query = query.where(
        and(
          query._.where,
          or(
            ilike(tasks.title, `%${search}%`),
            ilike(tasks.description, `%${search}%`)
          )
        )
      );
    }

    if (filter === "today") {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const tomorrow = new Date(today);
      tomorrow.setDate(tomorrow.getDate() + 1);
      
      query = query.where(
        and(
          query._.where,
          and(
            gte(tasks.dueDate, today),
            lt(tasks.dueDate, tomorrow)
          )
        )
      );
    } else if (filter === "overdue") {
      const now = new Date();
      query = query.where(
        and(
          query._.where,
          and(
            lt(tasks.dueDate, now),
            ne(tasks.status, "completed")
          )
        )
      );
    } else if (filter === "shared") {
      query = query.where(
        and(
          query._.where,
          ne(tasks.ownerId, userId)
        )
      );
    }

    // Apply sorting
    const sortColumn = sortBy === "dueDate" ? tasks.dueDate : 
                      sortBy === "priority" ? tasks.priority :
                      sortBy === "status" ? tasks.status : tasks.createdAt;
    
    query = sortOrder === "asc" ? 
      query.orderBy(asc(sortColumn)) : 
      query.orderBy(desc(sortColumn));

    // Get paginated results
    const results = await query.limit(limit).offset(offset);

    // Get collaborators for each task
    const tasksWithCollaborators = await Promise.all(
      results.map(async (result) => {
        const collaborators = await this.getTaskCollaborators(result.task.id);
        return {
          ...result.task,
          owner: result.owner,
          collaborators,
        };
      })
    );

    // Get total count
    const [totalResult] = await db
      .select({ count: count() })
      .from(tasks)
      .leftJoin(taskCollaborators, eq(tasks.id, taskCollaborators.taskId))
      .where(
        or(
          eq(tasks.ownerId, userId),
          eq(taskCollaborators.userId, userId)
        )
      );

    return {
      tasks: tasksWithCollaborators,
      total: totalResult.count,
    };
  }

  async getTask(id: number, userId: string): Promise<TaskWithOwnerAndCollaborators | undefined> {
    const [result] = await db
      .select({
        task: tasks,
        owner: users,
      })
      .from(tasks)
      .innerJoin(users, eq(tasks.ownerId, users.id))
      .leftJoin(taskCollaborators, eq(tasks.id, taskCollaborators.taskId))
      .where(
        and(
          eq(tasks.id, id),
          or(
            eq(tasks.ownerId, userId),
            eq(taskCollaborators.userId, userId)
          )
        )
      );

    if (!result) return undefined;

    const collaborators = await this.getTaskCollaborators(id);

    return {
      ...result.task,
      owner: result.owner,
      collaborators,
    };
  }

  async createTask(task: InsertTask): Promise<Task> {
    const [newTask] = await db.insert(tasks).values(task).returning();
    return newTask;
  }

  async updateTask(id: number, task: Partial<InsertTask>, userId: string): Promise<Task | undefined> {
    // Check if user has permission to update
    const existingTask = await this.getTask(id, userId);
    if (!existingTask) return undefined;

    const [updatedTask] = await db
      .update(tasks)
      .set({ ...task, updatedAt: new Date() })
      .where(eq(tasks.id, id))
      .returning();

    return updatedTask;
  }

  async deleteTask(id: number, userId: string): Promise<boolean> {
    // Only owner can delete task
    const result = await db
      .delete(tasks)
      .where(and(eq(tasks.id, id), eq(tasks.ownerId, userId)))
      .returning();

    return result.length > 0;
  }

  async addTaskCollaborator(taskId: number, userId: string, email: string): Promise<boolean> {
    // Check if task exists and user has permission
    const task = await this.getTask(taskId, userId);
    if (!task) return false;

    // Find user by email
    const collaboratorUser = await this.getUserByEmail(email);
    if (!collaboratorUser) return false;

    // Check if already a collaborator
    const [existing] = await db
      .select()
      .from(taskCollaborators)
      .where(
        and(
          eq(taskCollaborators.taskId, taskId),
          eq(taskCollaborators.userId, collaboratorUser.id)
        )
      );

    if (existing) return false;

    await db.insert(taskCollaborators).values({
      taskId,
      userId: collaboratorUser.id,
      canEdit: true,
    });

    return true;
  }

  async removeTaskCollaborator(taskId: number, userId: string, collaboratorId: string): Promise<boolean> {
    // Check if task exists and user has permission
    const task = await this.getTask(taskId, userId);
    if (!task) return false;

    const result = await db
      .delete(taskCollaborators)
      .where(
        and(
          eq(taskCollaborators.taskId, taskId),
          eq(taskCollaborators.userId, collaboratorId)
        )
      )
      .returning();

    return result.length > 0;
  }

  async getTaskCollaborators(taskId: number): Promise<(typeof taskCollaborators.$inferSelect & { user: User })[]> {
    const results = await db
      .select({
        collaborator: taskCollaborators,
        user: users,
      })
      .from(taskCollaborators)
      .innerJoin(users, eq(taskCollaborators.userId, users.id))
      .where(eq(taskCollaborators.taskId, taskId));

    return results.map(result => ({
      ...result.collaborator,
      user: result.user,
    }));
  }

  async getTaskCounts(userId: string): Promise<{
    total: number;
    today: number;
    overdue: number;
    shared: number;
  }> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    const now = new Date();

    const [totalResult] = await db
      .select({ count: count() })
      .from(tasks)
      .leftJoin(taskCollaborators, eq(tasks.id, taskCollaborators.taskId))
      .where(
        or(
          eq(tasks.ownerId, userId),
          eq(taskCollaborators.userId, userId)
        )
      );

    const [todayResult] = await db
      .select({ count: count() })
      .from(tasks)
      .leftJoin(taskCollaborators, eq(tasks.id, taskCollaborators.taskId))
      .where(
        and(
          or(
            eq(tasks.ownerId, userId),
            eq(taskCollaborators.userId, userId)
          ),
          gte(tasks.dueDate, today),
          lt(tasks.dueDate, tomorrow)
        )
      );

    const [overdueResult] = await db
      .select({ count: count() })
      .from(tasks)
      .leftJoin(taskCollaborators, eq(tasks.id, taskCollaborators.taskId))
      .where(
        and(
          or(
            eq(tasks.ownerId, userId),
            eq(taskCollaborators.userId, userId)
          ),
          lt(tasks.dueDate, now),
          ne(tasks.status, "completed")
        )
      );

    const [sharedResult] = await db
      .select({ count: count() })
      .from(tasks)
      .innerJoin(taskCollaborators, eq(tasks.id, taskCollaborators.taskId))
      .where(
        and(
          eq(taskCollaborators.userId, userId),
          ne(tasks.ownerId, userId)
        )
      );

    return {
      total: totalResult.count,
      today: todayResult.count,
      overdue: overdueResult.count,
      shared: sharedResult.count,
    };
  }
}

export const storage = new DatabaseStorage();
