# TaskFlow - Todo Task Management Web Application

## Overview

This is a full-stack collaborative todo task management web application built with modern web technologies. The application allows users to sign in using OAuth authentication, create and manage personal tasks, share tasks with other users, and collaborate in real-time.

## System Architecture

The application follows a full-stack architecture with:

- **Frontend**: React with Vite bundler
- **Backend**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Authentication**: Replit OAuth integration
- **Real-time Communication**: WebSockets
- **UI Framework**: Shadcn/UI with Radix UI components
- **Styling**: Tailwind CSS

## Key Components

### Frontend Architecture
- **React SPA**: Single-page application using React 18
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Form Handling**: React Hook Form with Zod validation
- **UI Components**: Comprehensive Shadcn/UI component library
- **Responsive Design**: Mobile-first approach with Tailwind CSS

### Backend Architecture
- **Express.js Server**: RESTful API with middleware architecture
- **Authentication**: Replit OAuth with Passport.js strategy
- **Session Management**: Express sessions with PostgreSQL store
- **Real-time Features**: WebSocket server for live task updates
- **Database Layer**: Drizzle ORM with type-safe queries

### Database Schema
- **Users Table**: Stores user profiles from OAuth providers
- **Tasks Table**: Core task entities with title, description, status, priority, due dates
- **Task Collaborators**: Junction table for task sharing functionality
- **Sessions Table**: Authentication session storage

### Authentication Flow
- OAuth integration with Replit authentication
- JWT-based session management
- Protected routes requiring authentication
- User profile management with first/last name and profile images

## Data Flow

1. **User Authentication**: OAuth flow through Replit's authentication service
2. **Task Operations**: CRUD operations through REST API endpoints
3. **Real-time Updates**: WebSocket connections for live collaboration
4. **Data Persistence**: PostgreSQL database with Drizzle ORM
5. **Client-Server Communication**: HTTP/HTTPS with WebSocket upgrades

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL database connection
- **drizzle-orm**: Type-safe database ORM
- **@tanstack/react-query**: Server state management
- **@radix-ui/***: Accessible UI component primitives
- **wouter**: Lightweight React router
- **react-hook-form**: Form state management
- **zod**: Runtime type validation

### Development Tools
- **Vite**: Fast development server and build tool
- **TypeScript**: Static type checking
- **ESBuild**: Fast JavaScript bundler
- **Tailwind CSS**: Utility-first CSS framework

## Deployment Strategy

### Development Environment
- **Vite Dev Server**: Hot module replacement for rapid development
- **Express Server**: Backend API server with development middleware
- **Database Migrations**: Drizzle Kit for schema management

### Production Build
- **Frontend**: Vite build process creates optimized static assets
- **Backend**: ESBuild bundles server code for Node.js deployment
- **Database**: Neon PostgreSQL for production database hosting
- **Environment Variables**: DATABASE_URL, SESSION_SECRET, OAUTH credentials

### Build Commands
- `npm run dev`: Development server with hot reloading
- `npm run build`: Production build for both frontend and backend
- `npm run start`: Production server startup
- `npm run db:push`: Apply database schema changes

## User Preferences

Preferred communication style: Simple, everyday language.

## Changelog

Changelog:
- July 01, 2025. Initial setup